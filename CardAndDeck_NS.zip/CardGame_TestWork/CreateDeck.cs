﻿using System;
using System.Collections.Generic;
using System.Security;
using System.Text;

namespace CardGame_TestWork{
	public class CreateDeck
	{
		public List<Card> deck = new List<Card>();

		//This Shuffle method needs improvement for real random!!
		private void shuffle()
        {
			int i = deck.Count;
			Random r = new Random();
            while ( i > 1)
            {
				int x = (r.Next(0,i)%i);
				i--;
				Card card = deck[x];
				deck[x] = deck[i];
				deck[i] = card;
            }
        }

		public CreateDeck(int[] rules)
		{
			//checks if jokers are added
            if (rules[4] == 1)
            {
				Card joker = new Card(0, "J1");
				deck.Add(joker);
				joker = new Card(0, "J2");
				deck.Add(joker);
            }
			//Add hearts
			for (int i = 1; i < 14; i++)
            {
				Card card = new Card(i, "H") ;
				deck.Add(card);
            }
			//add diamonds
			for (int i = 1; i < 14; i++)
			{
				Card card = new Card(i, "D");
				deck.Add(card);
			}
			//add clubs
			for (int i = 1; i < 14; i++)
			{
				Card card = new Card(i, "C");
				deck.Add(card);
			}
			//add spades
			for (int i = 1; i < 14; i++)
			{
				Card card = new Card(i, "S");
				deck.Add(card);
			}

			//Shuffle
			shuffle();

		}

	}
}
