﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Security;
using System.Text;

namespace CardGame_TestWork
{
    //"Program" here is obviously going to change, but the code here can be taken elsewhere. 
    class Program
    {
        static void Main(string[] args)
        { 
            //temp list of rules. 
            //rules[i] can be any rules. the number can either be 1 = ON, 0 = OFF. Or it can represent
            //a certain amount, such as number of cards held at a time. 
            //NOTE: Not all rules may apply to a deck!!
            int[] rules = {1,1,1,1,0};
            
            //creates a deck using CreateDeck object
            CreateDeck create = new CreateDeck(rules);
            List<Card> deck = create.deck;

            //Listing out Deck for testing
            deck.ForEach(delegate(Card i) {Console.WriteLine(i.Value + " " + i.Suit);});
            
        }
    }
}
